import streamlit as st
import snowflake.connector
import json


with open('config.json') as f:
    config = json.load(f)

#print(config['snowflake_user'])

'''# Initialize connection.
conn = snowflake.connector.connect(
    user=config["snowflake_user"],
    password=config["snowflake_password"],
    account=config["snowflake_account"],
    warehouse=config["warehouse"],
    database=config["database"],
    schema=config["schema"]
)'''

def get_snowflake_connection():
    conn = snowflake.connector.connect(
        user=config['snowflake_user'],
        password=config['snowflake_password'],
        account=config['snowflake_account'],
        warehouse=config['warehouse'],
        database=config['database'],
        schema=config['schema']
    )
    return conn

conn = get_snowflake_connection()
print("hello")
# Perform query.
query = "SELECT * FROM SALES LIMIT 10;"
df = conn.cursor().execute(query).fetch_pandas_all()

# Display results.
st.write(df)


